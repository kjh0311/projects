package kjh.running_machine_exercise_infomation_shower.common;

/**
 * Created by kimjin on 2016-05-15.
 */
public class HandlerController
{
	//Handler m_handler
}
