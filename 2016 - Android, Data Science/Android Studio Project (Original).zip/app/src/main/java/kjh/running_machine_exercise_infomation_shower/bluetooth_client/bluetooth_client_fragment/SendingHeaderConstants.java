package kjh.running_machine_exercise_infomation_shower.bluetooth_client.bluetooth_client_fragment;

/**
 * Created by kimjin on 2016-05-23.
 */
public class SendingHeaderConstants
{
	public static final
	byte
	MESSAGE = 0,
	IMAGE_START = 1,
	GRAD = 2,
	SPEED = 3,
	DISTANCE = 4,
	DISTANCE_CALCULATE_PROCESS = 5,
	WEIGHT = 6



	;

}
