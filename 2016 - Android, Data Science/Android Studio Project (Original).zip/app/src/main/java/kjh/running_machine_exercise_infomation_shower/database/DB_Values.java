package kjh.running_machine_exercise_infomation_shower.database;

import android.database.Cursor;

public class DB_Values
{
	private DB_Values prev_values;
	public String date,
			start, end, elapsed,
			kcal, km, grad, speed;
	private static final int
			DATE = 0, START_TIME = 1, END_TIME = 2, ELAPSED_TIME = 3,
			KCAL = 4, KM = 5, GRAD = 6, SPEED = 7;
	public DB_Values(Cursor cursor, DB_Values values)
	{
		prev_values = values;
		date = cursor.getString(DATE);
		start = cursor.getString(START_TIME);
		end = cursor.getString(END_TIME);
		elapsed = cursor.getString(ELAPSED_TIME);
		kcal = cursor.getString(KCAL);
		km = cursor.getString(KM);
		grad = cursor.getString(GRAD);
		speed = cursor.getString(SPEED);
	}

	public DB_Values get_previous_value() {
		return prev_values;
	}


	/*
		시작 시간을 키 값으로 쓰는 것은 비효율적이어 보이지만,
		값 삭제하는 빈도는 적을 것으로 예상되므로,
		키 값을 따로 만드는 것보다 이게 더 효율적일 듯 하다.
	 */

	public String getKey()
	{
		return start;
	}


	public String getTimeToShow()
	{
		String exercise_time, elapsed_time;
		StringBuilder builder;
		DB_ValueConverter converter;


		builder = new StringBuilder();
		converter = new DB_ValueConverter();
		exercise_time = converter.convert_exercise_time(start, end);
		elapsed_time = converter.convert_elapsed_time(elapsed);


		builder.append(exercise_time);
		builder.append("\n");
		builder.append(elapsed_time);
		builder.append("\n\n");


		return builder.toString();
	}


	public String getInformationToShow()
	{
		class Converted {
			String kcal, km, grad, speed;
		}
		DB_ValueConverter converter;
		Converted converted;
		StringBuilder values;


		converter = new DB_ValueConverter();
		converted = new Converted();
		values = new StringBuilder();

		converted.kcal = converter.convert_kcal(kcal);
		converted.km = converter.convert_km(km);
		converted.grad = converter.convert_grad(grad);
		converted.speed = converter.convert_speed(speed);


		values.append(converted.kcal);
		values.append("\t\t");
		values.append(converted.km);
		values.append("\n");
		values.append(converted.grad);
		values.append("\t\t");
		values.append(converted.speed);
		values.append("\n");


		return values.toString();
	}

}