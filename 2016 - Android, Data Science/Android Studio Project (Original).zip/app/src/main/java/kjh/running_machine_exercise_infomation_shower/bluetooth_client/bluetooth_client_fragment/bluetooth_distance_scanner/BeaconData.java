package kjh.running_machine_exercise_infomation_shower.bluetooth_client.bluetooth_client_fragment.bluetooth_distance_scanner;

/**
 * Created by kimjin on 2016-05-12.
 */
public class BeaconData
{
	public int received_order, filtered_rssi, rssi, tx, scan_count;
	public String address, name;
	public double distance;
	public String information_string;


	public String toString()
	{
		String text;

		text = "받은 순서: %d\n"
				+"검출한 횟수: %d\n"
				+"%s\n"
				+"주소: %s\n"
				+"거리: %.2f m\n"
				+"TX: %d dBm\n"
				+"받은 RSSI: %d dBm\n"
				+"수정된 RSSI: %d dBm\n"
				+"\n\nRSSI 처리한 과정\n%sdata end";
		text = String.format
				(text, received_order, scan_count, name,
						address, distance, tx, rssi,
						filtered_rssi, information_string);
		return text;
	}
}
