package kjh.running_machine_exercise_infomation_shower.bluetooth_client.bluetooth_client_fragment.bluetooth_distance_scanner;

/**
 * Created by kimjin on 2016-05-08.
 */
public class AddressSaver
{
	public static final int MAX_DEVICES = 4;
	private String m_address_array[];
	private int m_number_of_devices = 0;


	AddressSaver()
	{
		m_address_array = new String[MAX_DEVICES];
	}


	public int saveAddressAndRetrunIndex(String address)
	{
		int i;

		// 이미 받아놓은 주소인지 검사하고, i 값을 결정함
		for (i = 0; i < m_number_of_devices; i++)
		{
			if ( address.equals(m_address_array[i]) )
			{
				break;
			}
		}
		// 새로 받은 주소가 기존에 받았던 주소 중에 없다면,
		// 새로 받은 주소를 배열에 저장
		if ( i == m_number_of_devices)
		{
			if ( i >= MAX_DEVICES)
			{
				return MAX_DEVICES;
			}
			else
			{
				m_number_of_devices++;
				m_address_array[i] = address;
			}
		}

		return i;
	}
}
