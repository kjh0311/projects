package kjh.running_machine_exercise_infomation_shower.bluetooth_client.bluetooth_client_fragment.bluetooth_distance_scanner.filter;


import kjh.running_machine_exercise_infomation_shower.bluetooth_client.bluetooth_client_fragment.bluetooth_distance_scanner.filter.filter_details.AverageFilter;
import kjh.running_machine_exercise_infomation_shower.bluetooth_client.bluetooth_client_fragment.bluetooth_distance_scanner.filter.filter_details.MaxFilter;
import kjh.running_machine_exercise_infomation_shower.bluetooth_client.bluetooth_client_fragment.bluetooth_distance_scanner.filter.filter_details.ModeFilter;

/**
 * Created by kimjin on 2016-05-08.
 */
public class Filter
{
	public static int
			MAX_TRACK_COUNT = 3,
			ARRAY_TO_AVERAGE_LENGTH = 10,
			ARRAY_TO_MODE_LENGTH = 5;


	private AverageFilter m_average_filter;
	//private AverageFilter m_average_filter_l2;
	private MaxFilter m_max_filter;
	private ModeFilter m_mode_filter;
	private int m_filtered;
	private	ValueCollector
			m_unfiltered_collector,
			//m_tracking_max_collector,
			m_sampled_collector,
			m_summed_collector,
			m_number_to_average_collector,
			m_averaged_collector,
	/*
			m_summed_collector_l2,
			m_number_to_average_collector_l2,
			m_averaged_collector_l2,
			*/
			m_mode_value_collector;


	public Filter()
	{
		m_max_filter = new MaxFilter();
		m_average_filter = new AverageFilter();
		//m_average_filter_l2 = new AverageFilter();
		m_mode_filter = new ModeFilter();


		m_unfiltered_collector = new ValueCollector(30);
		//m_tracking_max_collector = new ValueCollector();
		m_sampled_collector = new ValueCollector();


		m_summed_collector = new ValueCollector();
		m_number_to_average_collector = new ValueCollector();
		m_averaged_collector = new ValueCollector();

/*
		m_summed_collector_l2 = new ValueCollector();
		m_number_to_average_collector_l2 = new ValueCollector();
		m_averaged_collector_l2 = new ValueCollector();
*/

		m_mode_value_collector = new ValueCollector();
	}


	// rssi 를 배열 멤버변수에 저장해서, 평균을 구함
	// 배열이 꽉차면 첫 번째 배열부터 덮어쓰기 시작함.
	public int filt(int value)
	{
		boolean max_value_sampled;


		m_unfiltered_collector.collect(value);

		max_value_sampled = m_max_filter.track_max_value(value);
		//m_tracking_max_collector.collect(m_max_filter.get_max_value());
		if (max_value_sampled)
		{
			value = m_max_filter.get_sampled_value();
			m_sampled_collector.collect(value);


			value = m_average_filter.average(value);
			m_summed_collector.collect(m_average_filter.getSum());
			m_number_to_average_collector.collect(m_average_filter.get_number_of_value());
			m_averaged_collector.collect(value);


			value = m_mode_filter.mode(value);
			m_mode_value_collector.collect(value);

			m_filtered = value;
		}
		return m_filtered;

	}


	public String getInformationString()
	{
		String unfiltered, tracking_max, sampled, summed, number_to_average, averaged, mode;
		String summed_l2, number_to_average_l2, averaged_l2;
		String track_number, max_average_number, mode_number;
		String max_average_number_l2;
		StringBuilder builder;


		unfiltered = "받은 값\n"+m_unfiltered_collector.toString();


		max_average_number = "\n\n\n평균화 배열 크기: "+ARRAY_TO_AVERAGE_LENGTH;
		summed = "\n합한 값\n"+m_summed_collector.toString();
		number_to_average = "\n나눌 값\n"+ m_number_to_average_collector.toString();
		averaged = "\n평균화된 값\n"+m_averaged_collector.toString();


		track_number = "\n\n\n최댓값 찾을 구간: "+MAX_TRACK_COUNT;
		//tracking_max = "\n구간 내에서 최댓값 찾는 과정\n"+m_tracking_max_collector.toString();
		sampled = "\n구간 내의 최댓값\n"+m_sampled_collector.toString();


		mode_number = "\n\n최빈값 구할 배열 크기: "+ARRAY_TO_MODE_LENGTH;
		mode = "\n최빈값\n"+m_mode_value_collector.toString();


		builder = new StringBuilder();
		builder.append(unfiltered);


		builder.append(track_number);
		//builder.append(tracking_max);
		builder.append(sampled);


		builder.append(max_average_number);
		builder.append(summed);
		builder.append(number_to_average);
		builder.append(averaged);
/*
		builder.append(max_average_number_l2);
		builder.append(summed_l2);
		builder.append(number_to_average_l2);
		builder.append(averaged_l2);
		*/

		builder.append(mode_number);
		builder.append(mode);

		return builder.toString();
	}


/*
	public FilterInformation getInformation()
	{
		FilterInformation information;
		information = new FilterInformation();
		information.max = m_max_filter.getInformation();
		information.average = m_average_filter.getInformation();
		information.mode = m_mode_filter.getInformation();
		return information;
	}
	*/
}
