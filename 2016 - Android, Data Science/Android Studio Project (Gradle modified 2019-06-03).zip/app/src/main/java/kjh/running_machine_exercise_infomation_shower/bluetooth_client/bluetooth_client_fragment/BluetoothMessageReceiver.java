package kjh.running_machine_exercise_infomation_shower.bluetooth_client.bluetooth_client_fragment;

public interface BluetoothMessageReceiver
{
    void use_received_message(String message);
}