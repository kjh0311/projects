package kjh.running_machine_exercise_infomation_shower.bluetooth_client.bluetooth_client_fragment;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;

import kjh.running_machine_exercise_infomation_shower.R;
import kjh.running_machine_exercise_infomation_shower.bluetooth_client.bluetooth_client_fragment.bluetooth_distance_scanner.BeaconData;
import kjh.running_machine_exercise_infomation_shower.bluetooth_client.bluetooth_client_fragment.bluetooth_distance_scanner.BluetoothDistanceScanner;
import kjh.running_machine_exercise_infomation_shower.bluetooth_client.bluetooth_client_fragment.bluetooth_distance_scanner.BluetoothDistanceUser;
import kjh.running_machine_exercise_infomation_shower.main_activity.MainActivity;
import kjh.running_machine_exercise_infomation_shower.tab1.Tab1Fragment;

/**
 * Created by kimjin on 2016-03-21.
 */
public class BluetoothClientFragment extends Fragment
	implements BluetoothDistanceUser
{
    private static final String
		    DESTINATION_ADDRESS
            = "00:1A:7D:DA:71:13",
		    BEACON_ADDRESS
			= "00:A0:50:11:28:24";

	public static final int
			SEND_SCREENSHOT_INTERVAL = 1000,
			SEND_SCREENSHOT_DELAY = 0
			//SEND_SCREENSHOT_DELAY = SEND_SCREENSHOT_INTERVAL
	;
	public static final int
			IDLE_TIME_SCREENSHOT_SENDING_DELAY = 3000;
			//IDLE_TIME_SCREENSHOT_SENDING_DELAY = 300;


	private boolean m_auto_connect = false;
	private boolean m_connected = false;
	private boolean m_connecting = false;

    private BluetoothMessageReceiver m_receiver;
    private BluetoothAdapter mBluetoothAdapter = null;
    private BluetoothChatService mChatService = null;
	private BluetoothDevice m_device = null;
	private BluetoothClientHandler mHandler;
	private BluetoothDistanceScanner m_distance_scanner;
	private TimerTask m_screenshot_send_task;
	private int m_screenshot_send_count;
	private int m_screenshot_send_max_count;
	private ToastShower mToastShower;




	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		// Get local Bluetooth adapter
		mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
		// If the adapter is null, then Bluetooth is not supported
		if (mBluetoothAdapter == null)
		{
			FragmentActivity activity = getActivity();
			Toast.makeText(activity, "Bluetooth is not available", Toast.LENGTH_LONG).show();
			activity.finish();
		}
		else if (m_auto_connect)
		{
			FragmentActivity activity = getActivity();
			mToastShower = new ToastShower(activity);

			mHandler = new BluetoothClientHandler(this);
			mChatService = new BluetoothChatService(getActivity(), mHandler);
			m_distance_scanner = new BluetoothDistanceScanner(activity, this);
			m_distance_scanner.startScan();
			//connect();
		}
	}


	@Override
	public void use_beacon_data(BeaconData data)
	{
		if (!data.address.equals(BEACON_ADDRESS))
			return;

		if (!m_connected && !m_connecting)
		{
			connect();
		}
		else if (!m_connecting)
		{
			send(SendingHeaderConstants.DISTANCE, String.format("%.2f", data.distance));
			send(SendingHeaderConstants.DISTANCE_CALCULATE_PROCESS, data.toString());
		}

		String str_distance = String.format("거리: %.2f", data.distance);
		Log.d("TAG",  str_distance);

		Activity a = getActivity();
		if (a!=null)
		{
			//Toast.makeText(getActivity(), str_distance, Toast.LENGTH_SHORT).show();
		}
	}


	public void set_connected(boolean true_or_false)
	{
		m_connected = true_or_false;
		m_connecting = false;
	}


	private void connect()
	{
		// Get the BluetoothDevice object
		m_device = mBluetoothAdapter.getRemoteDevice(DESTINATION_ADDRESS);

		mChatService.connect(m_device, false);
	    /* 일단 이렇게 true 로 하고,
	       연결 실패하면, 그 때 false 로 바꾸어서 연결이 재시도 될 수 있게 한다.
	      */
		m_connecting = true;

		if ( getActivity() == null ) return ;
		Toast.makeText(getActivity(), "연결", Toast.LENGTH_SHORT).show();
	}


	public void disconnect()
	{

		mChatService.start();
		mChatService.stop();
		mHandler.removeMessages(Constants.MESSAGE_CONNECT_FAILED);
		m_connected = false;
		if ( getActivity() == null ) return ;
		Toast.makeText(getActivity(), "연결해제", Toast.LENGTH_SHORT).show();
	}


	// onCreate 가 실행된 이후에 자동으로 연결하도록 예약한다.
	// 그리고 연결 실패시 무한하게 반복해서 연결시도 해야한다.
	public void set_auto_connect_and_set_receiver(BluetoothMessageReceiver receiver)
	{
		m_auto_connect = true;
		m_receiver = receiver;
	}


    public void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        // When the request to enable Bluetooth returns
        if (resultCode == Activity.RESULT_OK)
        {
            // Bluetooth is now enabled, so set up a chat session
            mChatService = new BluetoothChatService(getActivity(), mHandler);
        }
        else
        {
            // User did not enable Bluetooth or an error occurred
            // Log.d(TAG, "BT not enabled");
            Toast.makeText(getActivity(), R.string.not_connected, Toast.LENGTH_SHORT).show();
        }
    }


	public BluetoothMessageReceiver getReceiver()
	{
		return m_receiver;
	}

    @Override
    public void onDestroy()
    {
        super.onDestroy();
        if (mChatService != null)
        {
	        disconnect();
            //mChatService.stop();
        }
	    //mHandler.
    }

    @Override
    public void onResume()
    {
        super.onResume();

        // Performing this check in onResume() covers the case in which BT was
        // not enabled during onStart(), so we were paused to enable it...
        // onResume() will be called when ACTION_REQUEST_ENABLE activity returns.
        if (mChatService != null)
        {
            // Only if the state is STATE_NONE, do we know that we haven't started already
            if (mChatService.getState() == BluetoothChatService.STATE_NONE)
            {
				// Start the Bluetooth chat services
				mChatService.start();
            }
        }
    }


    public void connect_and_set_receiver(BluetoothMessageReceiver receiver)
    {
        // If BT is not on, request that it be enabled.
        // setupChat() will then be called during onActivityResult
        if (!mBluetoothAdapter.isEnabled())
        {
            Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableIntent, 0);
            /*
            위에 두 줄을 실행하면, 블루투스를 켤지 물어보고,
            아레에 있는 onActivityResult 메서드를 실행해서,
            OK 와 CANCEL 중 어느 버튼을 눌렀는가에 따라서 동작을 한다.
             */
        }
        else // 여기서 추가적인 준비동작을 한다.
        {
            //connect();
	        m_receiver = receiver;
        }
    }


	// 스크린샷 전송하는 동안은 비콘스캔 금지
	public void sendScreenShot(final int milis)
	{

		Timer timer;
		timer = new Timer();

		m_screenshot_send_max_count = milis / SEND_SCREENSHOT_INTERVAL;
		if (m_screenshot_send_task != null)
			m_screenshot_send_task.cancel();
		m_screenshot_send_task = new TimerTask() {
				@Override
				public void run() {
					//get_screenshot_by_using_handler();
					m_screenshot_send_count++;
					if (m_screenshot_send_count >= m_screenshot_send_max_count) {
						cancel();
						m_screenshot_send_task = null;
						//m_distance_scanner.startScan();
					}
				}
			};
		//m_distance_scanner.stopScan();
		timer.schedule(m_screenshot_send_task, SEND_SCREENSHOT_DELAY, SEND_SCREENSHOT_INTERVAL);

	}


	public void send_screenshot_continuously()
	{
		Timer timer;
		TimerTask task;
		timer = new Timer();
		task = new TimerTask() {
			@Override
			public void run() {
				get_screenshot_by_using_handler();
			}
		};
		//timer.schedule(task, 3000, 3000);
		timer.schedule(task, IDLE_TIME_SCREENSHOT_SENDING_DELAY, IDLE_TIME_SCREENSHOT_SENDING_DELAY);
	}

	Bitmap screenshot;
	View view;
	Handler handler;
	private void get_screenshot_by_using_handler()
	{
		//screenshot = get_screenshot();
		Message msg;
		if ( getActivity() == null) return;
		view = getActivity().getWindow().getDecorView();
		handler = new Handler(Looper.getMainLooper())
		{
			@Override
			public void handleMessage(Message msg)
			{
				view.setDrawingCacheEnabled(true);
				screenshot = view.getDrawingCache();//.copy(Bitmap.Config.ARGB_8888, false);

				if (screenshot != null)
				{
					//screenshot = screenshot.copy(Bitmap.Config.ARGB_8888, false);
					send_screenshot(screenshot);
					view.setDrawingCacheEnabled(false);
					//Toast.makeText(getActivity(), "스크린샷 전송", Toast.LENGTH_SHORT).show();
				}
				handler.removeMessages(0);
			}
		};
		msg = new Message();
		msg.what = 0;
		handler.sendMessageAtFrontOfQueue(msg);
		//handler.sendMessage(msg);
	}



    public void send(final byte sending_header_constant, String message)
    {
        //Toast.makeText(getActivity(), "보내기: " + message, Toast.LENGTH_SHORT).show();


        // Check that we're actually connected before trying anything
        if (mChatService.getState() != BluetoothChatService.STATE_CONNECTED)
        {
            Toast.makeText(getActivity(), R.string.not_connected, Toast.LENGTH_SHORT).show();
            return;
        }

        // Check that there's actually something to send
        if (message.length() > 0)
        {
	        byte[] delimeter = new byte[1];
	        delimeter[0] = sending_header_constant;
	        mChatService.write(delimeter);
            // Get the message bytes and tell the BluetoothChatService to write
            byte[] send = message.getBytes();
            mChatService.write(send);
        }
    }	

	
	private void send_screenshot(Bitmap screenshot)
	{

		if ( mChatService == null)
			return;

		//Toast.makeText(getActivity(), "스크린샷 전송", Toast.LENGTH_SHORT).show();
		// Check that we're actually connected before trying anything
		if (mChatService.getState() != BluetoothChatService.STATE_CONNECTED) {
			//Toast.makeText(activity, R.string.not_connected, Toast.LENGTH_SHORT).show();
			return;
		}


		String end_mark;
		byte[] delimiter;
		delimiter = new byte[1];

		delimiter[0] = SendingHeaderConstants.IMAGE_START;

		//m_distance_scanner.startScan();
		mChatService.write(delimiter);
		mChatService.sendBitmap(screenshot);
		end_mark = "image end";
		mChatService.write(end_mark.getBytes());
		//m_distance_scanner.stopScan();

	}

	String grad, speed;
	public void sendStartValue()
	{
		grad = getStartGradValue();
		speed = getStartSpeedValue();

		send(SendingHeaderConstants.GRAD, grad);
		mHandler.postDelayed(new Runnable() {
			public void run() {
				send(SendingHeaderConstants.SPEED, speed);
			}
		}, 1000);
	}

	private String getStartGradValue() {
		MainActivity a;
		View tab1;
		View start_value, grad_and_speed, grad, control_set, edit_value;

		a = (MainActivity)getActivity();
		tab1 = a.fragments.tab1.tab1;
		start_value = tab1.findViewById(R.id.start_value);
		grad_and_speed = start_value.findViewById(R.id.grad_and_speed);
		grad = grad_and_speed.findViewById(R.id.grad);
		control_set = grad.findViewById(R.id.control_set);
		edit_value = control_set.findViewById(R.id.edit_value);

		return ((EditText) edit_value).getText().toString();
	}

	private String getStartSpeedValue() {
		MainActivity a;
		View tab1;
		View start_value, grad_and_speed, speed, control_set, edit_value;

		a = (MainActivity)getActivity();
		tab1 = a.fragments.tab1.tab1;
		start_value = tab1.findViewById(R.id.start_value);
		grad_and_speed = start_value.findViewById(R.id.grad_and_speed);
		speed = grad_and_speed.findViewById(R.id.speed);
		control_set = speed.findViewById(R.id.control_set);
		edit_value = control_set.findViewById(R.id.edit_value);

		return ((EditText) edit_value).getText().toString();
	}
}
