package kjh.running_machine_exercise_infomation_shower.common;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;

/**
 * Created by kimjin on 2016-04-12.
 */
public class Sleep
{
	public static void thread_sleep(int millis)
	{
		try
		{
			Thread.sleep(millis);
		} catch (InterruptedException e)
		{
			e.printStackTrace();
		}
	}


	public static void main_sleep(final int millis)
	{
		Message msg;
		Handler handler;

		// Looper.getMainLooper(): 메인 쓰레드에서 동작하게 함
		handler = new Handler(Looper.getMainLooper()) {
			@Override
			public void handleMessage(Message msg)
			{
				// 전송할 수 있는 충분한 시간을 준다.
				thread_sleep(millis);
			}
		};
		msg = new Message();
		msg.what = 1;
		handler.sendMessage(msg);
	}
}
