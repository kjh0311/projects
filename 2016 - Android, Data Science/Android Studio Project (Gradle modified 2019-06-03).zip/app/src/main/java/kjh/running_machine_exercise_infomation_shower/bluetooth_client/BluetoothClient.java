package kjh.running_machine_exercise_infomation_shower.bluetooth_client;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Timer;
import java.util.TimerTask;

import kjh.running_machine_exercise_infomation_shower.common.Sleep;
import kjh.running_machine_exercise_infomation_shower.main_activity.MainActivity;
import kjh.running_machine_exercise_infomation_shower.R;
import kjh.running_machine_exercise_infomation_shower.bluetooth_client.bluetooth_client_fragment.BluetoothClientFragment;
import kjh.running_machine_exercise_infomation_shower.bluetooth_client.bluetooth_client_fragment.BluetoothMessageReceiver;
import kjh.running_machine_exercise_infomation_shower.database.DB_Helper;

/**
 * Created by kimjin on 2016-03-24.
 *
 * 이 클래스는,
 * 실행하자마자
 * BluetoothClientFragment 에 있는 방법대로
 * 특정 주소의 블루투스 디바이스로 접속해서,
 * 그 디바이스로 부터 정보를 얻어온다.
 *
 *
 * 이 동작을 하기 위해서,
 * 이 클래스는 BluetoothMessageReceiver 클래스를
 * implements 하고,
 * BluetoothClientFragment 클래스를 사용하고,
 * DB_Helper 클래스를 사용한다.
 * 그리고 그 결과를 반영하기 위해,
 * MainActivity 에 update 메서드를 불러,
 * 그 클래스에서 세부적인 update 를 한다.
 *
 */
public class BluetoothClient implements BluetoothMessageReceiver
{
    private MainActivity main_activity;
    private BluetoothClientFragment fragment;
    boolean wait_to_connect;
	boolean screen_sending;
    public BluetoothClient(MainActivity activity)
    {
        FragmentTransaction transaction;
        main_activity = activity;
        fragment = new BluetoothClientFragment();
        wait_to_connect = false;
	    screen_sending = false;
        transaction = activity.getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.activity_main, fragment);
        transaction.commit();
    }


    public void auto_connect()
    {
	    fragment.set_auto_connect_and_set_receiver(this);
	    // fragment 에서 onCreate 보다 이것이 먼저 실행될 수 없으므로,
	    // 위의 방법을 쓴다.
		//fragment.connect_and_set_receiver(this);
    }


    /*
    아래 메서드에서 메세지 받았을 때의 기능을 한다.
    제일 먼저는 테스트를 위해서 Toast를 부르고,
    그 다음에 데이터베이스 사용과 main_activity를 업데이트 하는 일을 한다.
     */
    @Override
    public void use_received_message(String message)
    {

	    DB_Helper db_helper;
	    StringBuilder insert_parameter;



	    db_helper = new DB_Helper(main_activity);
	    insert_parameter = new StringBuilder(message);
	    db_helper.insert(insert_parameter);


	    main_activity.update();


		//Toast.makeText(main_activity, message, Toast.LENGTH_LONG).show();
    }
	
	
	public void sendScreenShot(int milis)
	{
		//fragment.sendScreenShot(3000);
		fragment.sendScreenShot(milis);
	}


	public void send_screenshot_continuously()
	{
		fragment.send_screenshot_continuously();
	}


	public void send(byte sending_header, String text)
	{
		fragment.send(sending_header, text);
	}

/*
	private Bitmap get_screenshot()
	{

		// 아래 방법은 루팅이 되어있어야지만 가능함

		Process sh = null;
		try {
			return _get_screenshot();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return null;

	}


	private Bitmap _get_screenshot() throws IOException, InterruptedException {

		//Process sh = Runtime.getRuntime().exec("/system/bin/screencap -p ", null,null);
		Process sh = Runtime.getRuntime().exec("su", null,null);

		OutputStream  os = sh.getOutputStream();
		os.write(("/system/bin/screencap -p " + Environment.getExternalStorageDirectory() + File.separator + "img.png").getBytes("ASCII"));
		os.write(("/storage/emulated/0/img.png").getBytes("ASCII"));
		//os.write(("/sdcard/img.png").getBytes("ASCII"));
		os.flush();

		os.close();
		sh.waitFor();

		return BitmapFactory.decodeFile(Environment.getExternalStorageDirectory() + File.separator + "img.png");

	}
	*/



	//boolean is_sending = false;



}


