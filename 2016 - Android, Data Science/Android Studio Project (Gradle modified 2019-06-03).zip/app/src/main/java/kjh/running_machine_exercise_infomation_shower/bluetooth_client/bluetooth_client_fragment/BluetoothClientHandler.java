package kjh.running_machine_exercise_infomation_shower.bluetooth_client.bluetooth_client_fragment;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.v4.app.FragmentActivity;
import android.widget.Toast;

import kjh.running_machine_exercise_infomation_shower.main_activity.MainActivity;

/**
 * Created by kimjin on 2016-05-10.
 */
public class BluetoothClientHandler extends Handler
{
	BluetoothClientFragment m_fragment;
	//ReconnectThread m_reconnect_thread;
	BluetoothClientHandler(BluetoothClientFragment fragment)
	{
		super(Looper.getMainLooper());
		m_fragment = fragment;
		//m_reconnect_thread = new ReconnectThread();
	}


	@Override
	public void handleMessage(Message msg)
	{
		FragmentActivity activity;
		activity = m_fragment.getActivity();
		switch (msg.what)
		{
			case Constants.MESSAGE_READ:
				byte[] readBuf = (byte[]) msg.obj;
				// construct a string from the valid bytes in the buffer
				String readMessage = new String(readBuf, 0, msg.arg1);
				m_fragment.getReceiver().use_received_message(readMessage);
				break;

			// unable to connect device 같은 메세지를 출력한다.
			case Constants.MESSAGE_TOAST:
				if (null != activity) {
					Toast.makeText(activity, msg.getData().getString(Constants.TOAST),
							Toast.LENGTH_SHORT).show();
				}
				break;

			case Constants.MESSAGE_CONNECT_FAILED:
				m_fragment.set_connected(false);
				//m_reconnect_thread.start();
				break;


			case Constants.MESSAGE_CONNECTED:
				m_fragment.set_connected(true);
				m_fragment.sendScreenShot(BluetoothClientFragment.SEND_SCREENSHOT_INTERVAL);
				m_fragment.sendStartValue();
				break;

		}
	}

/*
	class ReconnectThread extends Thread
	{
		@Override
		public void run()
		{
			Sleep.thread_sleep(1000);
			m_fragment.reconnect();
		}
	}
	*/
}
