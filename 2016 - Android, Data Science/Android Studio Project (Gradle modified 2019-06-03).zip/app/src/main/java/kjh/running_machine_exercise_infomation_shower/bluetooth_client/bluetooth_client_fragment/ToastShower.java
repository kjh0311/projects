package kjh.running_machine_exercise_infomation_shower.bluetooth_client.bluetooth_client_fragment;

import android.content.Context;
import android.os.Handler;
import android.widget.Toast;

/**
 * Created by kimjin on 2016-05-14.
 */
public class ToastShower
{
	// UI 변경을 위해 필요함
	private Handler m_UI_handler;
	private ToastShowerRunnable m_runnable;
	private Context m_context;
	class ToastShowerRunnable implements Runnable
	{
		private String m_text;
		private Toast m_toast;
		ToastShowerRunnable(String text)
		{
			m_text = text;
		}
		@Override
		public void run()
		{
			if (m_toast!=null)
			{
				m_toast.cancel();
			}
			m_toast = Toast.makeText(m_context, m_text, Toast.LENGTH_SHORT);
			m_toast.show();
		}
	}

	ToastShower(Context context)
	{
		m_UI_handler = new Handler();
		m_context = context;
	}

	public void showToast(String text)
	{
		if (m_runnable != null)
		{
			m_UI_handler.removeCallbacks(m_runnable);
		}
		m_runnable = new ToastShowerRunnable(text);
		m_UI_handler.post(m_runnable);
	}
}
