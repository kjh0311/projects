package kjh.running_machine_exercise_infomation_shower.common;

import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import kjh.running_machine_exercise_infomation_shower.main_activity.MainActivity;
import kjh.running_machine_exercise_infomation_shower.database.*;

/**
 * Created by com on 2016-02-20.
 */
public class DailyExerciseInformationShower
{
	private static final int FONT_SIZE = 18;
	private MainActivity main_activity;
	private ScrollView scroll_view;
	private LinearLayout scroll_view_content;
	private DB_Helper db_helper;
	private int spinner_value;


	public DailyExerciseInformationShower(MainActivity main_activity, View scroll_view)
	{
		this.main_activity = main_activity;
		this.scroll_view = (ScrollView) scroll_view;
		db_helper = new DB_Helper(main_activity);
	}


	/* 아래 변수는 tab2 와 tab3 에서 독립적으로 사용된다. 다른 객체에 속한 변수이다.*/
	private String prev_date = null;
	public void show_one_day(int year, int month, int day)
	{
		prev_date = null;
		scroll_view.removeView(scroll_view_content);
		scroll_view_content = init_content();
		add_contents_by_date(year, month, day);
	}


	public void update_by_spinner_value()
	{
		prev_date = null;
		scroll_view.removeView(scroll_view_content);
		scroll_view_content = init_content();
		add_contents_by_spinner_value();
	}

	/** contents 를 담을 공간을 만든다. */
	private LinearLayout init_content()
	{
		LinearLayout new_layout;
		new_layout = new LinearLayout(main_activity);
		new_layout.setOrientation(LinearLayout.VERTICAL);
		scroll_view.addView(new_layout);

		return new_layout;
	}


	private void add_contents_by_spinner_value()
	{
		DB_Values db_values;
		db_values = db_helper.getValuesBySpinnerValue(spinner_value);
		show_all_values(db_values);
	}

	private void add_contents_by_date(int year, int month, int day)
	{
		DB_Values db_values;
		db_values = db_helper.getValuesByDate(year, month, day);
		show_all_values(db_values);
	}


	private void show_all_values(DB_Values db_values)
	{
		while (db_values != null )
		{
			show_values(db_values);
			db_values = db_values.get_previous_value();
		}
	}

	private void show_values(DB_Values values)
	{
		String date, str_value;
		date = values.date;
		if ( !date.equals(prev_date))
		{
			show_daily_values(date);
			prev_date = date;
		}
		show_values_in_time(values);
	}


	private void show_daily_values(String date)
	{
		DB_DailyValues daily_values;
		String date_to_show, total_values_to_show;


		daily_values = db_helper.getDailyValues(date);

		date_to_show = daily_values.getDateToShow();
		show_text_and_delete_button(date_to_show, date, DB_Helper.ColumnNames.DATE);
		total_values_to_show = daily_values.getTotalValuesToShow();
		show_text(total_values_to_show);
	}


	/*
	구분선, 운동정보 보여주기는 show_text 메소드를 이용하고,
	시간과 삭제버튼 보여주기는
	show_time_and_delete_button 메소르를 이용하며,
	파라미터로 time_to_show 와 key 를 보낸다.
	 */
	private void show_values_in_time(DB_Values values)
	{
		DB_ValueConverter converter;
		String key, separator, time_to_show, imformation_to_show;


		converter = new DB_ValueConverter();
		key = values.getKey();
		time_to_show = values.getTimeToShow();
		separator = converter.getSeparator(20);
		imformation_to_show = values.getInformationToShow();


		show_text(separator);
		show_text_and_delete_button(time_to_show, key, DB_Helper.ColumnNames.START_TIME);
		show_text(imformation_to_show);
	}


	private void show_text(String string)
	{
		show_text_in(scroll_view_content, string);
	}


	private void show_text_and_delete_button(String time_to_show, String key, String column_name)
	{
		LinearLayout layout;

		layout = new LinearLayout(main_activity);

		layout.setOrientation(LinearLayout.HORIZONTAL);

		show_text_in(layout, time_to_show);
		show_delete_button_in(layout, key, column_name);

		scroll_view_content.addView(layout);
	}


	private void show_text_in(ViewGroup group, String string)
	{
		TextView text;

		text = new TextView(main_activity);
		text.setText(string);
		text.setTextSize(FONT_SIZE);

		group.addView(text);
	}


	private void show_delete_button_in(ViewGroup group, final String key, final String column_name)
	{
		Button delete_button;

		delete_button = new Button(main_activity);
		delete_button.setText("삭 제");
		delete_button.setTextSize(FONT_SIZE);
		delete_button.setLayoutParams(new LinearLayout.LayoutParams(
				ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
		delete_button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				db_helper.delete_by_column_value(key, column_name);
				main_activity.update();
			}
		});

		group.addView(delete_button);
	}



	public void set_spinner_value(int spinner_value)
	{
		this.spinner_value = spinner_value;
	}
}


