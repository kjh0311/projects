package kjh.running_machine_exercise_infomation_shower.common;

import android.graphics.Bitmap;
import android.os.Environment;
import android.view.View;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import kjh.running_machine_exercise_infomation_shower.main_activity.MainActivity;

/**
 * Created by kimjin on 2016-03-29.
 */
public class Capture
{
	public void file_save(MainActivity activity)
	{
		View view;
		Bitmap screen_shot;
		String file_name;
		File f;

		view = activity.getWindow().getDecorView();
		view.setDrawingCacheEnabled(true);
		screen_shot = view.getDrawingCache();
		file_name = "screenshot.png";
		try
		{
			f = new File(Environment.getExternalStorageDirectory(),file_name);
			f.createNewFile();
			OutputStream outStream = new FileOutputStream(f);
			screen_shot.compress(Bitmap.CompressFormat.PNG, 100, outStream);
			outStream.close();
		}
		catch( IOException e)
		{
			e.printStackTrace();
		}
		view.setDrawingCacheEnabled(false);

	}
}
