package eml_parser;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.internet.MimeUtility;
import com.sun.mail.util.BASE64DecoderStream;



public class FileTester
{
	private static final String 
	SRC_DIR = "극지에서 온 eml 5개",
	EXTRACTED_SBD_FILES_DIR = "sbd파일 모음",
	DST_FILENAME = "수집된 데이터.csv",
	UTF8_BOM = "\uFEFF",
	COLUMN_HEADER = "파일 이름,날짜/시간\n",
	ROW_FORMAT = "%s,%s\n",
	DIR_NOT_FOUND = " 폴더가 없음";
	
	
	
	private static final int 
	TEXT_PART_INDEX = 0, ATTACHMENT_INDEX = 1;
	private static final String
	DATE_AND_TIME_PATTERN = "Time of Session \\(UTC\\): (.+)",
	FILE_SIZE_PATTERN = "Message Size \\(bytes\\): (\\d+)";
	
	
	
	public static void main(String[] args) throws IOException, MessagingException
	{
		new FileTester();
	}	
	private FileTester() throws IOException, MessagingException
	{
		File extracted_sbd_files_dir, src_dir, files[];
		
		
		extracted_sbd_files_dir = new File(EXTRACTED_SBD_FILES_DIR);
		if (extracted_sbd_files_dir.exists() == false)
		{
			extracted_sbd_files_dir.mkdir();
		}		
		src_dir = new File(SRC_DIR);
		files = src_dir.listFiles();		
		if (files == null)
		{
			System.out.println(SRC_DIR+DIR_NOT_FOUND);
		}
		else
		{			
			Session mail_session;
			BufferedWriter writer = null;
			
			mail_session = getMailSession();
			writer = new BufferedWriter(new FileWriter(DST_FILENAME));
			writer.write(UTF8_BOM+COLUMN_HEADER);
			for (int i = 0; i < files.length; i++)
			{
				File file = files[i];
				String str_file_name;
				String text;
				String date_and_time;
				
				
				text = get_text_and_save_attachment(file, mail_session);
				
				
				str_file_name = file.getName();
				date_and_time = get_data_by_regex(text, DATE_AND_TIME_PATTERN);				
				writer.write
				(String.format( ROW_FORMAT, 
				 str_file_name, date_and_time));
			}
			writer.close();
		}
	}
	
	
	private String get_text_and_save_attachment(File file, Session mail_session) throws MessagingException, IOException
	{		
		FileInputStream source;
		MimeMessage message;
		Object content;
		String text;
		
		
		source = new FileInputStream(file);	
		message = new MimeMessage(mail_session, source);
		content = message.getContent();
		
		// 첨부파일이 있는 경우
		if (content instanceof MimeMultipart) {
			MimeMultipart multipart = (MimeMultipart)content;			
			text = get_text_and_save_attachment_in_multipart(multipart);					
		} else {				
			text = (String)content;
		}		
		return text;
	}
	
	

	private String get_text_and_save_attachment_in_multipart(MimeMultipart multipart) throws IOException, MessagingException
	{
		BodyPart bodypart;
		String text;		
		
		bodypart = multipart.getBodyPart(TEXT_PART_INDEX);				
		text = (String)bodypart.getContent();
		save_attachment(text, multipart);
        return text;
	}
	
	
	private void save_attachment(String text, MimeMultipart multipart) throws MessagingException, IOException
	{
		String str_file_size;
		int file_size;
		BodyPart bodypart;
		byte[] attachment_buffer;
		String attachment_filename, attachment_filepath;
		BASE64DecoderStream decoder_stream;		
		
		
		bodypart = multipart.getBodyPart(ATTACHMENT_INDEX);
		attachment_filename = MimeUtility.decodeText(bodypart.getFileName());
		attachment_filepath = String.format("%s/%s",
											EXTRACTED_SBD_FILES_DIR,
											attachment_filename);
		str_file_size = get_data_by_regex(text, FILE_SIZE_PATTERN);
		file_size = Integer.parseInt(str_file_size);
		attachment_buffer = new byte[file_size];
		decoder_stream = (BASE64DecoderStream) bodypart.getContent();
		read(attachment_buffer, decoder_stream);
        save(attachment_filepath, attachment_buffer);
	}
	
	
	private void read(byte[] attachment_buffer, BASE64DecoderStream decoder_stream) throws IOException
	{
		BufferedInputStream buffered_input_stream;
		buffered_input_stream = new BufferedInputStream(decoder_stream);
        buffered_input_stream.read(attachment_buffer);
        buffered_input_stream.close();
	}
	
	
	private void save(String attachment_filepath, byte[] attachment_buffer) throws IOException
	{
		FileOutputStream file_output_stream;
		BufferedOutputStream buffered_output_stream;
		
		file_output_stream = new FileOutputStream(attachment_filepath);
        buffered_output_stream = new BufferedOutputStream(file_output_stream);
        buffered_output_stream.write(attachment_buffer);
        buffered_output_stream.close();
	}
	
	
	private Session getMailSession()
	{
		Properties props;
		props = System.getProperties();
		props.put("mail.host", "smtp.dummydomain.com");
		props.put("mail.transport.protocol", "smtp");
		return Session.getDefaultInstance(props, null);
	}
	
	
	String get_data_by_regex(String source, String str_pattern)
	{
		Pattern pattern; Matcher matcher;
		pattern =Pattern.compile(str_pattern, Pattern.MULTILINE);
		matcher = pattern.matcher(source);
		if (matcher.find())
		{
			return matcher.group(1);
		}
		else
		{
			return "못 찾음";
		}
	}
}

