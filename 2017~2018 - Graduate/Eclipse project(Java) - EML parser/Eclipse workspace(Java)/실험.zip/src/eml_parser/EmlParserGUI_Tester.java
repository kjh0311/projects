package eml_parser;

import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;

public class EmlParserGUI_Tester
{
	public static void main(String args[])
	{
		new EmlParserGUI_Tester();
	}
	
	private EmlParserGUI_Tester()
	{
		new EmlParserWindow();
	}
}


class EmlParserWindow extends JFrame
{
	private Dimension 
	screenSize;
	static final int 
	WIDTH = 500, HEIGHT = 500;
		
	public EmlParserWindow()
	{
		super("극지에서 온 이메일 분석");
		setVisible(true);
		setDefaultCloseOperation
			(EXIT_ON_CLOSE);
		setSize(WIDTH,HEIGHT);
		screenSize = Toolkit.getDefaultToolkit().getScreenSize();		
		setLocation((screenSize.width - WIDTH) / 2,
				(screenSize.height - HEIGHT) / 2);		
	}
	
}



