package ui.gui_controller.specifyRange;

public class SpecifyRangeGUI_Parameters
{	
	static class Label {
		
	}
	
	static class RadioButton {
		
	}
	
	static class PushButton {
		
	}
	
	static class Spinner {
		
	}
	
	
	
	
}
