package ui;

import javax.swing.JFrame;

import ui.main.Bounds;
import ui.main.Strings;

public class EmlParserWindow extends JFrame
{
	public EmlParserWindow() {
		super(Strings.TITLE);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(Bounds.WIDTH, Bounds.HEIGHT);
	}
}
